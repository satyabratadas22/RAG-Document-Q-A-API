"""Evaluate the RAG pipeline on a labelled set and compare prompt versions.

eval_set.json format:
[{"question": "...", "reference": "short gold answer", "source": "file.pdf", "answerable": true}, ...]
Add ~5 "answerable": false questions (out-of-scope) to measure correct abstention.
"""
import argparse
import json
import statistics as st

from rouge_score import rouge_scorer

from ragqa.chunking import load_documents
from ragqa.generate import HFGenerator
from ragqa.index import SentenceTransformerEmbedder, VectorIndex
from ragqa.pipeline import RAGPipeline


def run(pipeline: RAGPipeline, items):
    scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
    rl, hit, grounded, ttft, tps = [], [], [], [], []
    abst_ok, abst_total, answered_unanswerable = 0, 0, 0
    for it in items:
        out = pipeline.ask(it["question"])
        if it.get("answerable", True):
            hit.append(any(s["source"] == it["source"] for s in out["sources"]))
            rl.append(scorer.score(it["reference"], out["answer"])["rougeL"].fmeasure)
            if out["grounded"] is not None:
                grounded.append(out["grounded"])
        else:
            abst_total += 1
            abst_ok += out["abstained"]
            answered_unanswerable += (not out["abstained"])
        if out["metrics"]:
            ttft.append(out["metrics"]["ttft_s"])
            tps.append(out["metrics"]["tokens_per_s"])
    mean = lambda xs: round(st.mean(xs), 3) if xs else None
    return {
        "retrieval_hit@k": mean(hit), "rougeL": mean(rl), "mean_grounded": mean(grounded),
        "correct_abstain_rate": round(abst_ok / abst_total, 3) if abst_total else None,
        "unanswerable_answered": answered_unanswerable,
        "mean_ttft_s": mean(ttft), "mean_tokens_per_s": mean(tps), "n": len(items),
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", default="data/docs")
    ap.add_argument("--eval", default="data/eval_set.json")
    ap.add_argument("--prompts", nargs="+", default=["v1", "v2"])
    ap.add_argument("--out", default="eval_results.json")
    args = ap.parse_args()

    items = json.load(open(args.eval, encoding="utf-8"))
    index = VectorIndex(SentenceTransformerEmbedder())
    gen = HFGenerator()
    pipe = RAGPipeline(index, gen)
    print("chunks indexed:", pipe.ingest(load_documents(args.docs)))

    results = {}
    for v in args.prompts:
        pipe.prompt_version = v
        results[v] = run(pipe, items)
        print(v, json.dumps(results[v], indent=2))
    json.dump(results, open(args.out, "w"), indent=2)
