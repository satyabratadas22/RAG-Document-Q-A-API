# RAG DocQA

Retrieval-augmented question answering over your own documents (PDF/TXT/MD), served with FastAPI.

**Pipeline:** load docs -> overlapping chunks -> sentence-transformer embeddings -> FAISS cosine search
-> context-window budgeting -> versioned prompt -> Hugging Face LLM (streaming) -> grounding check -> answer or abstain.

**Reliability features**
- Abstains when the best retrieval score is below a threshold (`min_score`).
- Lexical grounding check blocks answers that share too few content words with the retrieved context (a cheap hallucination proxy, not a full fact-check).
- Prompt versions (`v1`, `v2`) compared with the same evaluation script.
- Measures TTFT and tokens/second.

## Run (Google Colab or local, GPU optional)
```bash
pip install -r requirements.txt
pytest -q                      # unit tests, no model download needed
# a sample corpus (5 docs) and 20 labelled questions are already included; add your own docs/questions to extend
python eval.py --prompts v1 v2 # prints retrieval hit@k, ROUGE-L, grounding, abstain rate, TTFT, TPS
uvicorn ragqa.api:app --port 8000
curl -X POST localhost:8000/ask -H "Content-Type: application/json" -d '{"question":"..."}'
```

## Results (fill in from your own run)
| Prompt | hit@k | ROUGE-L | grounded | correct abstain | TTFT (s) | tokens/s |
|---|---|---|---|---|---|---|
| v1 | | | | | | |
| v2 | | | | | | |
