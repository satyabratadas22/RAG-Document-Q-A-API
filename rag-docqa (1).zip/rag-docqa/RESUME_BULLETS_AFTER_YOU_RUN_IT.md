Fill the blanks ONLY with numbers from your own eval_results.json, then send them to me and I will patch the resume.

**RAG Document Q&A API** | Python, Hugging Face Transformers, FAISS, sentence-transformers, FastAPI, PyTorch | Oct 2026
- Built a RAG service over ___ documents (___ chunks): overlapping chunking, FAISS cosine retrieval, context-window budgeting and a streaming Hugging Face LLM (Qwen2.5-0.5B-Instruct) behind a FastAPI endpoint.
- Reduced hallucinations with a retrieval-score threshold and a context-grounding filter; correctly abstained on ___% of ___ out-of-scope questions.
- Evaluated on ___ labeled questions: hit@4 ___%, ROUGE-L ___; compared 2 prompt versions; measured TTFT ___ s and ___ tokens/s; covered with ___ unit tests (pytest).
