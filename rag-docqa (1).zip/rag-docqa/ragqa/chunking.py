from pathlib import Path
from typing import List, Tuple


def chunk_text(text: str, max_words: int = 180, overlap: int = 40) -> List[str]:
    """Split text into overlapping word windows."""
    if max_words <= overlap:
        raise ValueError("max_words must be greater than overlap")
    words = text.split()
    chunks: List[str] = []
    step = max_words - overlap
    for start in range(0, len(words), step):
        piece = words[start:start + max_words]
        if piece:
            chunks.append(" ".join(piece))
        if start + max_words >= len(words):
            break
    return chunks


def load_documents(folder: str) -> List[Tuple[str, str]]:
    """Return (source_name, text) for every .txt/.md/.pdf file in a folder."""
    docs: List[Tuple[str, str]] = []
    for path in sorted(Path(folder).rglob("*")):
        if path.suffix.lower() in {".txt", ".md"}:
            docs.append((path.name, path.read_text(encoding="utf-8", errors="ignore")))
        elif path.suffix.lower() == ".pdf":
            from pypdf import PdfReader
            text = "\n".join((p.extract_text() or "") for p in PdfReader(str(path)).pages)
            docs.append((path.name, text))
    return docs
