from dataclasses import dataclass
from typing import Callable, List

import faiss
import numpy as np


@dataclass
class Chunk:
    source: str
    text: str


class SentenceTransformerEmbedder:
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def __call__(self, texts: List[str]) -> np.ndarray:
        vecs = self.model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(vecs, dtype="float32")


class VectorIndex:
    """FAISS inner-product index over L2-normalised embeddings (= cosine similarity)."""

    def __init__(self, embedder: Callable[[List[str]], np.ndarray]):
        self.embedder = embedder
        self.chunks: List[Chunk] = []
        self.index = None

    def add(self, chunks: List[Chunk]) -> None:
        if not chunks:
            return
        vecs = self.embedder([c.text for c in chunks])
        if self.index is None:
            self.index = faiss.IndexFlatIP(vecs.shape[1])
        self.index.add(vecs)
        self.chunks.extend(chunks)

    def search(self, query: str, k: int = 4):
        if self.index is None or not self.chunks:
            return []
        q = self.embedder([query])
        scores, ids = self.index.search(q, min(k, len(self.chunks)))
        return [(float(s), self.chunks[i]) for s, i in zip(scores[0], ids[0]) if i != -1]
