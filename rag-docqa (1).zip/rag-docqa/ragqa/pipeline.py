import re
from typing import Callable, Dict, List

from .chunking import chunk_text
from .index import Chunk, VectorIndex
from .prompts import ABSTAIN_MESSAGE, DEFAULT_PROMPT, build_prompt

_STOP = set("a an the of to in and or is are was were be for on with as by at from that this it its into than then".split())


def _content_words(text: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP and len(w) > 2}


def grounded_fraction(answer: str, context: str) -> float:
    """Share of the answer's content words that appear in the retrieved context.

    A cheap lexical proxy for hallucination, NOT a semantic fact-check.
    """
    words = _content_words(answer)
    if not words:
        return 0.0
    return len(words & _content_words(context)) / len(words)


class RAGPipeline:
    def __init__(
        self,
        index: VectorIndex,
        generator: Callable,
        prompt_version: str = DEFAULT_PROMPT,
        top_k: int = 4,
        min_score: float = 0.30,
        min_grounded: float = 0.50,
        max_context_words: int = 700,
    ):
        self.index = index
        self.generator = generator
        self.prompt_version = prompt_version
        self.top_k = top_k
        self.min_score = min_score
        self.min_grounded = min_grounded
        self.max_context_words = max_context_words

    def ingest(self, documents: List[tuple], max_words: int = 180, overlap: int = 40) -> int:
        chunks = [Chunk(src, c) for src, text in documents for c in chunk_text(text, max_words, overlap)]
        self.index.add(chunks)
        return len(chunks)

    def _build_context(self, hits) -> str:
        """Add chunks best-first until the context word budget is used up."""
        parts, used = [], 0
        for _, chunk in hits:
            n = len(chunk.text.split())
            if parts and used + n > self.max_context_words:
                break
            parts.append(f"[{chunk.source}] {chunk.text}")
            used += n
        return "\n\n".join(parts)

    def ask(self, question: str) -> Dict:
        hits = self.index.search(question, self.top_k)
        sources = [{"source": c.source, "score": round(s, 3)} for s, c in hits]
        if not hits or hits[0][0] < self.min_score:
            return {"answer": ABSTAIN_MESSAGE, "abstained": True, "reason": "low_retrieval_score",
                    "sources": sources, "grounded": None, "metrics": {}}

        context = self._build_context(hits)
        prompt = build_prompt(self.prompt_version, context, question)
        answer, metrics = self.generator(prompt)

        if answer.strip() == ABSTAIN_MESSAGE:
            return {"answer": answer, "abstained": True, "reason": "model_abstained",
                    "sources": sources, "grounded": None, "metrics": metrics}

        grounded = grounded_fraction(answer, context)
        if grounded < self.min_grounded:
            return {"answer": ABSTAIN_MESSAGE, "abstained": True, "reason": "low_grounding",
                    "raw_answer": answer, "sources": sources, "grounded": round(grounded, 3),
                    "metrics": metrics}
        return {"answer": answer, "abstained": False, "reason": None, "sources": sources,
                "grounded": round(grounded, 3), "metrics": metrics}
