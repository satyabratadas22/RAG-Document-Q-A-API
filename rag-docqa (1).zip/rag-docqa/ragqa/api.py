import os

from fastapi import FastAPI
from pydantic import BaseModel

from .chunking import load_documents
from .generate import HFGenerator
from .index import SentenceTransformerEmbedder, VectorIndex
from .pipeline import RAGPipeline

app = FastAPI(title="RAG DocQA")
_pipeline = None


def get_pipeline() -> RAGPipeline:
    global _pipeline
    if _pipeline is None:
        index = VectorIndex(SentenceTransformerEmbedder())
        _pipeline = RAGPipeline(index, HFGenerator(), prompt_version=os.getenv("PROMPT_VERSION", "v2"))
        _pipeline.ingest(load_documents(os.getenv("DOCS_DIR", "data/docs")))
    return _pipeline


class Question(BaseModel):
    question: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/ask")
def ask(q: Question):
    return get_pipeline().ask(q.question)
