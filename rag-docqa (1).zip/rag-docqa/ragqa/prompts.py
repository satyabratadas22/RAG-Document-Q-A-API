"""Versioned prompt templates. Evaluate each version with eval.py before changing the default."""

PROMPTS = {
    "v1": (
        "Answer the question using the context.\n\n"
        "Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    ),
    "v2": (
        "You are a careful assistant. Answer ONLY from the context below. "
        "If the context does not contain the answer, reply exactly: "
        "\"I don't know based on the provided documents.\" "
        "Keep the answer short and cite the source name in square brackets.\n\n"
        "Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    ),
}

DEFAULT_PROMPT = "v2"
ABSTAIN_MESSAGE = "I don't know based on the provided documents."


def build_prompt(version: str, context: str, question: str) -> str:
    if version not in PROMPTS:
        raise KeyError(f"Unknown prompt version: {version}")
    return PROMPTS[version].format(context=context, question=question)
