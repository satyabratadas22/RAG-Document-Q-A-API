import time
from threading import Thread
from typing import Dict, Tuple


class HFGenerator:
    """Streaming text generation with a small Hugging Face instruct model.

    Measures time-to-first-token (TTFT) and tokens/second (TPS).
    """

    def __init__(self, model_name: str = "Qwen/Qwen2.5-0.5B-Instruct", device: str = None):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.model.eval()

    def __call__(self, prompt: str, max_new_tokens: int = 160) -> Tuple[str, Dict[str, float]]:
        from transformers import TextIteratorStreamer
        messages = [{"role": "user", "content": prompt}]
        text = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(text, return_tensors="pt").to(self.device)
        streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True, skip_special_tokens=True)
        kwargs = dict(**inputs, streamer=streamer, max_new_tokens=max_new_tokens, do_sample=False)

        start = time.perf_counter()
        thread = Thread(target=self.model.generate, kwargs=kwargs)
        thread.start()
        pieces, ttft = [], None
        for piece in streamer:
            if ttft is None and piece:
                ttft = time.perf_counter() - start
            pieces.append(piece)
        thread.join()
        total = time.perf_counter() - start
        answer = "".join(pieces).strip()
        n_tokens = len(self.tokenizer(answer)["input_ids"]) if answer else 0
        gen_time = max(total - (ttft or 0.0), 1e-6)
        return answer, {
            "ttft_s": ttft if ttft is not None else total,
            "tokens_per_s": n_tokens / gen_time,
            "total_s": total,
            "new_tokens": n_tokens,
        }
