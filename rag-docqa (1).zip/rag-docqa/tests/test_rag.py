import hashlib
import numpy as np

from ragqa.chunking import chunk_text
from ragqa.index import VectorIndex
from ragqa.pipeline import RAGPipeline, grounded_fraction
from ragqa.prompts import ABSTAIN_MESSAGE, build_prompt


def fake_embedder(texts, dim=256):
    """Deterministic bag-of-words embedder so tests need no model download."""
    out = np.zeros((len(texts), dim), dtype="float32")
    for i, t in enumerate(texts):
        for w in t.lower().split():
            out[i, int(hashlib.md5(w.encode()).hexdigest(), 16) % dim] += 1.0
        n = np.linalg.norm(out[i])
        if n:
            out[i] /= n
    return out


def make_pipeline(generator, **kw):
    pipe = RAGPipeline(VectorIndex(fake_embedder), generator, **kw)
    pipe.ingest([
        ("cats.txt", "cats are small domestic animals that purr and sleep most of the day"),
        ("space.txt", "jupiter is the largest planet in the solar system and has many moons"),
    ], max_words=50, overlap=10)
    return pipe


def test_chunk_overlap_and_coverage():
    text = " ".join(f"w{i}" for i in range(100))
    chunks = chunk_text(text, max_words=40, overlap=10)
    assert len(chunks) == 3
    assert chunks[0].split()[-10:] == chunks[1].split()[:10]
    assert chunk_text("") == []


def test_chunk_invalid_params():
    try:
        chunk_text("a b c", max_words=5, overlap=5)
        assert False
    except ValueError:
        pass


def test_retrieval_finds_relevant_source():
    pipe = make_pipeline(lambda p: ("jupiter is the largest planet", {}), min_score=0.1)
    hits = pipe.index.search("which planet is the largest", 2)
    assert hits[0][1].source == "space.txt"


def test_abstains_on_low_retrieval_score():
    pipe = make_pipeline(lambda p: ("anything", {}), min_score=0.9)
    out = pipe.ask("what is the capital of france")
    assert out["abstained"] and out["answer"] == ABSTAIN_MESSAGE
    assert out["reason"] == "low_retrieval_score"


def test_grounded_answer_passes_and_hallucination_blocked():
    good = make_pipeline(lambda p: ("Jupiter is the largest planet [space.txt]", {"ttft_s": 0.1, "tokens_per_s": 5}),
                         min_score=0.1)
    assert not good.ask("which planet is the largest")["abstained"]
    bad = make_pipeline(lambda p: ("Bananas ferment quickly inside submarines", {}), min_score=0.1)
    out = bad.ask("which planet is the largest")
    assert out["abstained"] and out["reason"] == "low_grounding"


def test_context_budget_limits_chunks():
    pipe = make_pipeline(lambda p: ("x", {}), min_score=0.0, max_context_words=5)
    ctx = pipe._build_context(pipe.index.search("planet cats", 2))
    assert ctx.count("[") == 1


def test_prompt_versions():
    assert "Context:" in build_prompt("v1", "c", "q")
    try:
        build_prompt("v9", "c", "q")
        assert False
    except KeyError:
        pass


def test_grounded_fraction_bounds():
    assert grounded_fraction("", "anything") == 0.0
    assert grounded_fraction("jupiter planet", "jupiter planet moons") == 1.0
